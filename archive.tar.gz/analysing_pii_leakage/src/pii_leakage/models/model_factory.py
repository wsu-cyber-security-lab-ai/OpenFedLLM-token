# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

from ..arguments.env_args import EnvArgs
from ..arguments.model_args import ModelArgs
from .gpt2 import GPT2
from .llama3 import LLama3
from .language_model import LanguageModel


class ModelFactory:
    @staticmethod
    def from_model_args(model_args: ModelArgs, env_args: EnvArgs = None) -> LanguageModel:
        if "opt" in model_args.architecture:
            raise NotImplementedError
        elif "gpt" in model_args.architecture:
            print("found gpt model")
            return GPT2(model_args=model_args, env_args=env_args)
        elif "meta-llama/Llama-3.2-1B-Instruct" in model_args.architecture:
            print("found meta-llama/Llama-3.2-1B-Instruct model")
            return LLama3(model_args=model_args, env_args=env_args)
        else:
            raise ValueError(model_args.architecture)
